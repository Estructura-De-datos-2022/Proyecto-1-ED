#ifndef OBJETO_H
#define OBJETO_H


class Objeto
{
    public:
        Objeto() {}
        virtual ~Objeto() {}

    protected:

    private:
};

#endif // OBJETO_H

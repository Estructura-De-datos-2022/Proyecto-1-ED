#ifndef CONSTANTES_H
#define CONSTANTES_H


class Constantes
{
    public:
        static final int ARRIBA=0;
        static final int ABAJO=1;
        static final int IZQUIERDA=2;
        static final int DERECHA=3;

        static final int X=0;
        static final int Y=1;

        static final bool VISITADO=0;
        bool ES_FINAL=1;
        bool TIENE_OBJETO=2;
};

#endif // CONSTANTES_H

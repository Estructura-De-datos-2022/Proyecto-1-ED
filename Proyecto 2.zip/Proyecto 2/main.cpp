#include <iostream>
#include "GrafoEspecial.h"
#include "NodoEspecial.h"
#include "GrafoEspecial2.h"
#include "NodoEspecial2.h"
#include "time.h"
#include <SFML/Graphics.hpp>
using namespace std;
void profundidad(){
    /*cout<<"Determine la cantidad de filas del mapa: ";
    int filas;
    cin>>filas;
    cout<<"Determine la cantidad de columnas del mapa: ";
    int columnas;
    cin>>columnas;*/
    GrafoEspecial* grafo=new GrafoEspecial(5,5);
    grafo->print();
    NodoEspecial* laberintoProfundidad=grafo->crearArbolDeExpansionProfundidad();

}
void profundidad2(){
    cout<<"Determine la cantidad de filas del mapa: ";
    int filas;
    cin>>filas;
    cout<<"Determine la cantidad de columnas del mapa: ";
    int columnas;
    cin>>columnas;
    GrafoEspecial2* grafo=new GrafoEspecial2(filas,columnas);
    grafo->print();
    NodoEspecial2* laberintoProfundidad=grafo->crearArbolDeExpansionProfundidad();
    grafo->printConnections(laberintoProfundidad);

}
void anchura2(){
    cout<<"Determine la cantidad de filas del mapa: ";
    int filas;
    cin>>filas;
    cout<<"Determine la cantidad de columnas del mapa: ";
    int columnas;
    cin>>columnas;
    GrafoEspecial2* grafo=new GrafoEspecial2(filas,columnas);
    grafo->print();
    NodoEspecial2* laberintoAnchura=grafo->crearArbolDeExpansionAnchura();
    grafo->printConnections(laberintoAnchura);
}
void prim2(){
    cout<<"Determine la cantidad de filas del mapa: ";
    int filas;
    cin>>filas;
    cout<<"Determine la cantidad de columnas del mapa: ";
    int columnas;
    cin>>columnas;
    GrafoEspecial2* grafo=new GrafoEspecial2(filas,columnas);
    grafo->print();
    NodoEspecial2* laberintoPrim=grafo->crearArbolDeExpansionPrim();
    grafo->printConnections(laberintoPrim);
}
void anchura(){
    cout<<"Determine la cantidad de filas del mapa: ";
    int filas;
    cin>>filas;
    cout<<"Determine la cantidad de columnas del mapa: ";
    int columnas;
    cin>>columnas;
    GrafoEspecial* grafo=new GrafoEspecial(5,5);
    grafo->print();
    NodoEspecial* laberintoAnchura=grafo->crearArbolDeExpansionAnchura();

}
void prim(){
    cout<<"Determine la cantidad de filas del mapa: ";
    int filas;
    cin>>filas;
    cout<<"Determine la cantidad de columnas del mapa: ";
    int columnas;
    cin>>columnas;
    GrafoEspecial* grafo=new GrafoEspecial(5,5);
    grafo->print();
    NodoEspecial* laberintoPrim=grafo->crearArbolDeExpansionPrim();

}
int main(){
    srand(time(0));
    while(true){
        cout<<"1- Laberinto de profundidad"<<endl;
        cout<<"2- Laberinto de anchura"<<endl;
        cout<<"3- Laberinto de prim"<<endl;
        cout<<"Determine el recorrido de laberinto que desea implementar: ";
        int numero;
        cin>>numero;
        if (numero==1){
            profundidad2();
        }
        if(numero==2){
            anchura2();
        }
        if(numero==3){
            prim2();
        }
        cout<<"�Desea realizar otro recorrido?(S/N) ";
        string letra;
        cin>>letra;
        if(letra=="N"){
            break;
        }
    }
    return 0;
}
int main2()
{
    int numFilas = 5;
    int numColumnas = 5;
    GrafoEspecial* grafo=new GrafoEspecial(numFilas,numColumnas);
    grafo->print();
    NodoEspecial* laberintoProfundidad=grafo->crearArbolDeExpansionProfundidad();
    for (int i = 0; i < grafo->numeroColumnas*grafo->numeroFilas; i++){
        cout << laberintoProfundidad[i].getNumero() << "Esta conectado en: " << endl;
        if (laberintoProfundidad[i].conexionArriba!=nullptr){
            cout <<"Por arriba con: " << laberintoProfundidad[i].conexionArriba->getNumero() << endl;
        }
        if (laberintoProfundidad[i].conexionAbajo!=nullptr){
            cout <<"Por abajo con: " << laberintoProfundidad[i].conexionAbajo->getNumero() << endl;
        }
        if (laberintoProfundidad[i].conexionDerecha!=nullptr){
            cout <<"Por derecha con: " << laberintoProfundidad[i].conexionDerecha->getNumero() << endl;
        }
        if (laberintoProfundidad[i].conexionIzquierda!=nullptr){
            cout <<"Por izquierda con: " << laberintoProfundidad[i].conexionIzquierda->getNumero() << endl;
        }
    }
    //profundidad();
    sf::RenderWindow window(sf::VideoMode(650, 650), "Proyecto 2 Estructuras de Datos");
    sf::RectangleShape rect[grafo->numeroColumnas*grafo->numeroFilas];
    int x = 0, y = 0, i = 0;
    int nodofila = 0;
    int nodocol = 0;
    while (window.isOpen()){
        sf::Event event;
        while(window.pollEvent(event)){
            if (event.type == sf::Event::Closed)
                window.close();
        }
        window.clear();
        while (i < grafo->numeroColumnas*grafo->numeroFilas) {
            rect[i].setSize(sf::Vector2f(20, 20));
            if (nodofila < numFilas){
                if (laberintoProfundidad[i].conexionDerecha!=nullptr){
                    //cout << laberintoProfundidad[i].getNumero() << "entro a conexion derecha" << endl;
                    rect[i].setSize(sf::Vector2f(20+35, 20));
                    rect[i].setPosition(x,y);
                    window.draw(rect[i]);
                    x += 35;
                    i++;
                    nodofila++;
                }
                else if(laberintoProfundidad[i].conexionAbajo!=nullptr){
                    //cout << laberintoProfundidad[i].conexionAbajo->getNumero() << "entro a conexion abajo" << endl;
                    rect[i].setSize(sf::Vector2f(20, 20+35));
                    rect[i].setPosition(x,y);
                    window.draw(rect[i]);
                    x += 35;
                    i++;
                    nodofila++;
                }
                else{
                    rect[i].setPosition(x,y);
                    window.draw(rect[i]);
                    x += 35;
                    i++;
                    nodofila++;
                }
            }else{
                y += 35;
                x = 0;
                nodofila = 0;
                //rect[i].setPosition(x,y);
                //window.draw(rect[i]);
                if (laberintoProfundidad[i].conexionDerecha!=nullptr){
                    //cout << laberintoProfundidad[i].getNumero() << "entro a conexion derecha" << endl;
                    rect[i].setSize(sf::Vector2f(20+35, 20));
                    rect[i].setPosition(x,y);
                    window.draw(rect[i]);
                    x += 35;
                    i++;
                    nodofila++;
                }
                else if(laberintoProfundidad[i].conexionAbajo!=nullptr){
                    //cout << laberintoProfundidad[i].conexionAbajo->getNumero() << "entro a conexion abajo" << endl;
                    rect[i].setSize(sf::Vector2f(20, 20+35));
                    rect[i].setPosition(x,y);
                    window.draw(rect[i]);
                    x += 35;
                    i++;
                    nodofila++;
                }
                else{
                rect[i].setPosition(x,y);
                window.draw(rect[i]);
                x += 35;
                i++;
                nodofila++;
                }
            }
            rect[21].setFillColor(sf::Color::Red);
            rect[22].setFillColor(sf::Color::Blue);
            //cout << laberintoProfundidad[0].getNumero() << endl;

            /*rect[i].setPosition(x, y);

            window.draw(rect[i]);

            x += 25;

            y += 25;

            i++;*/
        }
        //cout << laberintoProfundidad[5].conexionDerecha->getNumero() << endl;
        i = 0;
        x = 0;
        y = 0;
        window.display();
    }
    /*sf::RectangleShape shape(sf::Vector2f(20.f,20.f));
    shape.setFillColor(sf::Color::Red);
    shape.setPosition(1,1);

    while (window.isOpen())
    {
        sf::Event event;
        while (window.pollEvent(event))
        {
            if (event.type == sf::Event::Closed)
                window.close();
        }

        window.clear();
        window.draw(shape);
        //window.display();
        shape = sf::RectangleShape(sf::Vector2f(10.f,10.f));
        shape.setPosition(30,100);
        window.draw(shape);
        window.display();
    }*/
    /*srand(time(0));
    while(true){
        cout<<"1- Laberinto de profundidad"<<endl;
        cout<<"2- Laberinto de anchura"<<endl;
        cout<<"3- Laberinto de prim"<<endl;
        cout<<"Determine el recorrido de laberinto que desea implementar: ";
        int numero;
        cin>>numero;
        if (numero==1){
            profundidad();
        }
        if(numero==2){
            anchura();
        }
        if(numero==3){
            prim();
        }
        cout<<"�Desea realizar otro recorrido?(S/N) ";
        string letra;
        cin>>letra;
        if(letra=="N"){
            break;
        }
    }*/
    return 0;
}
